# mazegen

Perfect maze generator with **Prim's algorithm** and a **BFS shortest-path solver**.

Generates rectangular mazes of arbitrary size, with optional "42" decorative
pattern locked in the centre. Output is suitable for ASCII rendering or
programmatic use.

## Installation

```bash
pip install mazegen-1.0.0-py3-none-any.whl
```

Requires Python 3.10 or later.

## Quick start

```python
from mazegen import MazeGenerator, MazeSolver

# Generate a 20x20 maze with the "42" pattern embedded
gen = MazeGenerator(20, 20, seed=42, add_42=True)
gen.generate()

# Get the maze as a list of hex strings (one per row)
for line in gen.to_hex_lines():
    print(line)

# Solve from top-left to bottom-right
solver = MazeSolver(gen.get_grid())
path = solver.solve((0, 0), (19, 19))
print(path)            # "EESSESE..." direction string
print(len(path))       # shortest-path length in steps
```

## Public API

| Name | Purpose |
|---|---|
| `MazeGenerator` | Build a maze with Prim's algorithm (plus optional 42 pattern) |
| `MazeSolver` | Find the shortest path between two cells using BFS |
| `Grid` | Rectangular cell grid (wall state per cell) |
| `Cell` | Single cell with 4-bit wall state |
| `AMazeError` | Base exception; catch this to handle all package errors |
| `ConfigError`, `ConfigFileNotFoundError`, `InvalidParameterError` | Configuration problems |
| `MazeGenerationError`, `NoPathError`, `MazeTooSmallError` | Runtime problems |
| `OutputWriteError` | File output problems |

## How walls are encoded

Each cell stores its four walls as a 4-bit integer, exposed via `cell.to_hex()`
as a single hex digit (`0` to `F`):

| Bit | Direction | Value |
|---|---|---|
| 0 | N | 1 |
| 1 | E | 2 |
| 2 | S | 4 |
| 3 | W | 8 |

A set bit means the wall is **closed**. `F` (= `1111`) means a fully walled
cell; `0` means a fully open cell.

## Reproducibility

Pass a `seed` to `MazeGenerator` to get deterministic output. Two generators
constructed with the same `(width, height, seed)` produce byte-identical mazes.

```python
a = MazeGenerator(10, 10, seed=7); a.generate()
b = MazeGenerator(10, 10, seed=7); b.generate()
assert a.to_hex_lines() == b.to_hex_lines()
```

## Error handling

All package errors derive from `AMazeError`, so a single `except` clause
suffices for top-level error handling:

```python
from mazegen import AMazeError

try:
    gen = MazeGenerator(3, 3, algorithm="unknown")
    gen.generate()
except AMazeError as exc:
    print(f"mazegen failed: {exc}")
```

## License

MIT.
