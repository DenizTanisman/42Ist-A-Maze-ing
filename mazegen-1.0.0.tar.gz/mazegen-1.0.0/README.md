# A-Maze-ing — Takım Çalışma Rehberi

> Bu dosya **ikimiz için** ortak referans. Görev dağılımı, takvim, ortak kararlar burada. Bireysel detaylar için `Deniz.md` ve `Fatih.md` dosyalarına bakın.

---

## Takım

| Rol | Kişi | Sorumluluk |
|---|---|---|
| 🅰️ Algoritma Mühendisi | **Deniz** | Üretim mantığı + reusable paket |
| 🅱️ Sistem ve Etkileşim Mühendisi | **Fatih** | Girdi/çıktı + görselleştirme + CLI |

---

## 9 Günlük Takvim (Genel Bakış)

```
GÜN     DENİZ (A)                      FATİH (B)
────────────────────────────────────────────────────────────
0       ┌── Day 0 Toplantı (1-2 saat, beraber) ──┐
        │  Sözleşmeler + repo kurulumu           │
        └────────────────────────────────────────┘

1       A1 — Veri Modeli (Cell + Grid)     B1 — Config Parser
2       A1 devam + testler                 B1 bitir + B2 başla
3       A2 — Üretim Algoritması             B2 — Output Writer + B3 başla
4       A2 devam + A3 başla (BFS)          B3 — Terminal Renderer
5       A3 bitir + A4 — 42 Deseni          B3 bitir + B4 — Etkileşim

6       ┌── ENTEGRASYON GÜNÜ (beraber) ──────────┐
        │  Mock'lar kaldırılır, gerçek modüller  │
        │  End-to-end test                        │
        │  A5 — Paketleme + B5 — CLI/Makefile    │
        └─────────────────────────────────────────┘

7       BUFFER + Test + README + bug fix       BUFFER + Test + README + bug fix
        Norminette/lint kontrol                Norminette/lint kontrol

8       Evaluation hazırlığı (defense provası)
9       Evaluation günü
```

**Kritik:** Gün 6 entegrasyon günü — ikiniz **aynı anda** çalışın. Mock'tan gerçeğe geçişte sürpriz çıkma ihtimali yüksek.

---

## Day 0 Sözleşmesi — Birlikte Karar Verilecek Maddeler

Kodlamaya başlamadan önce bu maddelere **yazılı** karar verilmeli. Karar verildikten sonra `CONTRACT.md` dosyasına yazılır, ikinizin de referansı olur.

### 1. Yön (Direction) Kodlaması
```
Bit pozisyon: 3 2 1 0
Yön:          W S E N

Koordinat sistemi:
- (0,0) sol üst köşe
- x sağa artar (East)
- y aşağı artar (South)
```
**Onaylandığında değişmez.** İkiniz de bu tabloya göre kod yazacak.

### 2. Grid Public API
Deniz hazırlar, Fatih kullanır. Fatih'in çağıracağı metodlar:
- `Grid.width`, `Grid.height`
- `Grid.get(x, y)` → hücre döner
- `Grid.in_bounds(x, y)` → boolean
- `Grid.neighbors(x, y)` → komşu listesi
- Hücrenin duvar bilgisine erişim (`cell.has_wall(direction)` veya benzeri)
- Hücrenin hex değerini alma (`cell.to_hex()` veya `grid.cell_hex(x, y)`)

### 3. MazeGenerator Public API
- `__init__(width, height, seed=None, algorithm='backtracker')`
- `generate()` → çağrıldıktan sonra labirent hazır
- `get_grid()` → Grid nesnesi döner
- `solve(entry, exit)` → path döner (örn. `['N','E','S','S','W']`)
- `to_hex_lines()` → dosya formatı için satır listesi

### 4. Mock Veri Politikası
- Fatih, Deniz'in modülünü beklemeden çalışabilmek için **mock üretici** kullanır
- Mock'un API'si gerçek modülle birebir aynı olur
- Gerçek modül hazırlanınca tek import değişikliği ile gerçeğine geçilir

### 5. Hata Yönetimi
- Deniz'in modülleri **exception fırlatır**, error mesajı yazmaz
- Fatih'in CLI'ı **exception'ları yakalar** ve kullanıcıya gösterir
- Custom exception sınıfları kullanılır: `ConfigError`, `MazeGenerationError`, `InvalidParameterError` (isimlere beraber karar verin)

### 6. Repo Branching
```
main                              ← protected
├── deniz/core
├── deniz/generator
├── deniz/solver
├── deniz/patterns
├── deniz/packaging
├── fatih/config
├── fatih/output
├── fatih/renderer
├── fatih/interaction
└── fatih/cli
```
- Doğrudan `main`'e push **YOK**
- Her özellik kendi branch'inde, biten branch PR ile merge edilir
- Diğer kişi PR'ı **okur ve onaylar** sonra merge

---

## Repo İskeleti (Day 0'da hazırlanır)

Aşağıdaki klasör yapısı **Day 0 toplantısında ikiniz beraber** oluşturulur. Sonra herkes kendi alanında çalışır.

```
a_maze_ing/
├── a_maze_ing.py              # Fatih — ana CLI
├── config.txt                  # Fatih — default config
├── README.md                   # Beraber
├── CONTRACT.md                 # Day 0'da yazılır, sözleşmeler
├── Deniz.md                    # Deniz'in kişisel görev listesi
├── Fatih.md                    # Fatih'in kişisel görev listesi
├── Makefile                    # Fatih
├── pyproject.toml              # Deniz (paket için)
├── .gitignore                  # Fatih
├── .flake8                     # Fatih
├── mypy.ini                    # Fatih
│
├── mazegen/                    # Deniz'in alanı (paket)
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── cell.py
│   │   └── grid.py
│   ├── generator.py
│   ├── solver.py
│   └── patterns.py
│
├── io_handlers/                # Fatih'in alanı
│   ├── __init__.py
│   ├── config_parser.py
│   └── output_writer.py
│
├── visual/                     # Fatih'in alanı
│   ├── __init__.py
│   ├── terminal.py
│   └── interaction.py
│
├── mocks/                      # Beraber (Day 0)
│   ├── __init__.py
│   └── fake_grid.py
│
└── tests/
    ├── __init__.py
    ├── test_grid.py            # Deniz
    ├── test_generator.py       # Deniz
    ├── test_solver.py          # Deniz
    ├── test_patterns.py        # Deniz
    ├── test_config_parser.py   # Fatih
    ├── test_output_writer.py   # Fatih
    └── test_renderer.py        # Fatih
```

---

## Günlük Senkron (Stand-up)

Her gün **15 dakika**, sabah veya akşam:
1. Dün ne yaptım?
2. Bugün ne yapacağım?
3. Blocker var mı? (varsa karşı taraftan ne istiyorum?)

Discord/Telegram/yüz yüze — fark etmez, **yazılı** olsun. Geriye dönük referans için.

---

## Geliştirme Disiplini

- ✅ Her küçük iş kendi branch'inde
- ✅ Hiçbir commit `main`'e doğrudan gitmez
- ✅ Public API değişikliği → diğer kişiyle önce konuşulur
- ✅ Mock'lar gerçek modül hazır olunca silinir
- ✅ Her PR'da kendi test'lerin yeşil olmalı
- ✅ `flake8` ve `mypy` her PR öncesi temiz olmalı
- ❌ Yarım iş merge edilmez
- ❌ "Sonra düzeltirim" yorumu kabul edilmez

---

## Defense Hazırlığı (Gün 8)

Birbirinizin kodunu **okumadan** defense'e girmeyin. Evaluator rastgele soru sorar — "şuradaki kod neden böyle?" diye Fatih'e Deniz'in kodunu sorabilir.

### Deniz'in savunacağı konular
- Algoritma seçimi ve neden bu algoritma
- Spanning tree ile perfect maze ilişkisi
- BFS vs DFS — neden BFS shortest path
- Bit encoding mantığı
- Paketin başka projede nasıl import edileceği
- 42 deseni yerleştirme stratejisi

### Fatih'in savunacağı konular
- Config validation katmanları
- Hata yönetimi stratejisi (program neden çökmüyor)
- Path traversal gibi güvenlik kararları
- Terminal rendering tercihi (neden ASCII / Unicode)
- Etkileşim state machine'i
- Makefile lint flag'lerinin anlamı

---

## AI Kullanım Şeffaflığı

PDF'in zorunlu kıldığı README başlığı. Hangi adımlarda AI kullandığınızı **dürüstçe** yazın. Örneğin:
- Algoritma karşılaştırma analizi için Claude ile tartışıldı
- BFS implementation'ı bireysel olarak yazıldı
- README taslağı yapısı için AI önerisi alındı

Şeffaflık güven kazandırır. Saklamak yakalanırsan ağır maliyetli.

---

## Acil Durum Protokolü

**Eğer bir kişi gün 5'e kadar bir görevi bitiremezse:**
1. Karşı tarafa hemen söylenir
2. Görev kapsamı kısaltılır (bonus özellikler atılır)
3. Buffer günü (Gün 7) feda edilir
4. Defense'e gitmek için minimum gereksinimler **non-negotiable**:
   - Üretim çalışıyor
   - Dosya çıktısı doğru
   - Görselleştirme var
   - 42 deseni gözüküyor
   - Paket build oluyor
   - README tam

Bonus özellikler (animasyon, MLX, multi-algoritma) bitebilirse iyi, bitmezse atılır.
